package servlets;

public class j2ee {

}
