package insertrec;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;

public class insertquery {

	public static void main(String[] args)  {
		// TODO Auto-generated method stub
Connection con=null;
Statement st=null;
String q="insert into jspider.tablename1 values(10,'bha')";
try {
	Class.forName("com.mysql.jdbc.Driver");
	con=DriverManager.getConnection("jdbc:mysql://localhost:3306?user=root&password=bhav");
	st=con.createStatement();
	st.executeUpdate(q);
	System.out.println("data is inserted successfully");
} catch (ClassNotFoundException | SQLException e) {
	// TODO Auto-generated catch block
	e.printStackTrace();
}
finally
{
	if(st!=null)
		try {
			st.close();
		}catch(SQLException e)
	{e.printStackTrace();
		}
	if(con!=null)
		try {
			con.close();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
}

	}

}
